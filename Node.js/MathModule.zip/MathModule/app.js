var math = require('./mathlib')();

console.log(math.add(1,2))
console.log(math.multiply(10,10))